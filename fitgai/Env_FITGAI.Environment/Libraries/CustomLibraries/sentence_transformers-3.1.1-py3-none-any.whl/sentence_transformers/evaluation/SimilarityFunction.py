from __future__ import annotations

from sentence_transformers.similarity_functions import SimilarityFunction

__all__ = ["SimilarityFunction"]
